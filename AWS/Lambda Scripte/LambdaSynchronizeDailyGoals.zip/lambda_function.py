import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['DigitSpanTasks']['values']
    
    print(message) 
    user_id = data2['nameValuePairs']['user_id'] 
    
    if (message != ['']):

        for dailyGoal in message:
            
            #retrieve all Data from Body in individual variables:
            #additional Data
            dailygoal = json.loads(dailyGoal)
            wholestemp = dailygoal['Date']
            timestamp = wholestemp.split(" ")
            
            dailyTask = dailygoal['Daily_Task']
            progress = dailygoal['Progress']
            
             
            #operate on rds with MySQL
            with conn.cursor() as cur:
                cur.execute(f'SELECT * FROM DailyGoal WHERE user_id = "{user_id}" AND stamp >= timestamp("{timestamp[0]} 00:00:00") AND stamp <= timestamp("{timestamp[0]} 23:59:59");') 
        
                result = cur.fetchone()
                if result is None:
                    cur.execute(f'INSERT INTO DailyGoal (user_id, stamp, dailyTask, progress) VALUES ("{user_id}", "{wholestemp}", "{dailyTask}", {progress});')
                    
                elif result[4] < progress and result[3] == dailyTask:
                    cur.execute(f'DELETE FROM DailyGoal WHERE dailyTaskID = "{result[0]}"')
                    cur.execute(f'INSERT INTO DailyGoal (user_id, stamp, dailyTask, progress) VALUES ("{user_id}", "{wholestemp}", "{dailyTask}", {progress});')
            conn.commit()        
             

    body = list()
    with conn.cursor() as cur:
         cur.execute(f'SELECT JSON_OBJECT("Date", stamp, "Daily_Task", dailyTask, "Progress", progress, "user_id", user_id) AS json_object FROM DailyGoal WHERE user_id = "{user_id}" ORDER BY stamp;')
         result2 = cur.fetchall()
         for x in result2:
             body.append(x[0])
    

    http_res['body'] = json.dumps(body)         
    return http_res   
    #return successful http res
    