import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['completedInterventions']['values']
    
    print(message) 
    user_id = data2['nameValuePairs']['user_id'] 
    
    if (message != ['']):

        for completedInterventions in message:
            #retrieve all Data from Body in individual variables:
            #additional Data
            print(completedInterventions)
            
            completedInterventions = json.loads(rf'{completedInterventions}')
            wholestemp = completedInterventions['timestamp']
            timestamp = wholestemp.split(" ")
            daytime = timestamp[1].split(":")
            
            id = completedInterventions['id']
            completed = completedInterventions['completed']
            notes = completedInterventions['notes']
            rating = completedInterventions['rating']
            
            #operate on rds with MySQL
            with conn.cursor() as cur:
                cur.execute(f'SELECT * FROM completedInterventions WHERE user_id = "{user_id}" AND stamp = timestamp("{wholestemp}");') 
        
                result = cur.fetchone()
                
                if result is None:
                    cur.execute(f'INSERT INTO completedInterventions (user_id, stamp, id, completed, notes, rating) VALUES ("{user_id}", "{wholestemp}", {id}, {completed}, "{notes}", {rating});')
                    conn.commit()
             
    body = list()
    with conn.cursor() as cur:
         cur.execute(f'SELECT JSON_OBJECT("timestamp", stamp, "id", id, "completed", completed, "notes", notes, "rating", rating) AS json_object FROM completedInterventions WHERE user_id = "{user_id}" ORDER BY stamp;')
         result2 = cur.fetchall()
         print(result2)
         for x in result2:
             body.append(x[0])
    
    http_res['body'] = json.dumps(body)
    #return successful http res
    return http_res