import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']

    username = message['username']
    userpassword = message['password']


    with conn.cursor() as cur:
        cur.execute(f'SELECT user_id FROM UniqueUserId WHERE user_name = "{username}" AND user_password = "{userpassword}";') 
        result = cur.fetchone()
        if result != None:
            http_res['body'] = result[0]
        else:
            http_res['body'] = "-1" #returns -1 if the Login Information was in
        conn.commit()
     #returns UUID

        

    
    #return successful http response
    return http_res