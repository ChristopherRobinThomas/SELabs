import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    print(event)
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['DigitSpanTasks']['values']
    print(message) 
    user_id = data2['nameValuePairs']['user_id'] 
    
    if (message != ['']):

        for digitspantask in message:
            #retrieve all Data from Body in individual variables:
            #additional Data
            digitspantask = json.loads(digitspantask)
            wholestemp = digitspantask['timestamp']
            timestamp = wholestemp.split(" ")
            
            
            initSpanLengtToday = digitspantask['InitSpanLengtToday']
            initSpanLengthTomorrow = digitspantask['InitSpanLengthTomorrow']
            maxKnownNumbers = digitspantask['MaxKnownNumbers']
            numberOfSuccessfulRounds = digitspantask['numberOfSuccessfulRounds']
            
            
             
            #operate on rds with MySQL
            with conn.cursor() as cur:
                cur.execute(f'SELECT * FROM DigitSpanTask WHERE user_id = "{user_id}" AND stamp >= timestamp("{timestamp[0]} 00:00:00") AND stamp <= timestamp("{timestamp[0]} 23:59:59");') 
        
                result = cur.fetchone()
                
                if result is None:
                    cur.execute(f'INSERT INTO DigitSpanTask (user_id, stamp, initSpanLengthToday, initSpanLengthTomorrow, maxKnownNumbers, numberOfSuccessfulRounds) VALUES ("{user_id}", "{wholestemp}", {initSpanLengtToday}, {initSpanLengthTomorrow}, {maxKnownNumbers}, {numberOfSuccessfulRounds});')
                    conn.commit()
             
             
    body = list()
    with conn.cursor() as cur:
         cur.execute(f'SELECT JSON_OBJECT("InitSpanLengtToday", initSpanLengthToday, "InitSpanLengthTomorrow", initSpanLengthTomorrow, "MaxKnownNumbers", maxKnownNumbers, "numberOfSuccessfulRounds", numberOfSuccessfulRounds, "timestamp", stamp, "user_id", user_id) AS json_object FROM DigitSpanTask WHERE user_id = "{user_id}" ORDER BY stamp;')
         result2 = cur.fetchall()
         print(result2)
         for x in result2:
             body.append(x[0])
    
    print(body)
    http_res['body'] = json.dumps(body)         
    return http_res
    #return successful http res
    