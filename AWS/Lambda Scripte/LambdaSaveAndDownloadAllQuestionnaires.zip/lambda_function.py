import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['Questionnaires']['values']
    print(message) 
    user_id = data2['nameValuePairs']['user_id'] 
    
    if (message != ['']):

        for questionnaire in message:
            #retrieve all Data from Body in individual variables:
            #additional Data
            questionnaire = json.loads(questionnaire)
            wholestemp = questionnaire['timestamp']
            timestamp = wholestemp.split(" ")
            daytime = timestamp[1].split(":")
            timeslot = "";
            if daytime[0] == '07' or daytime[0] == '08' or daytime[0] == '09' or daytime[0] == '10':
                timeslot = "morning"
            elif daytime[0] == '12' or daytime[0] == '13':
                timeslot = "lunch"
            elif daytime[0] == '17' or daytime[0] == '18':
                timeslot = "evening"
        
            #Question 1
            q1_1 = questionnaire['Q1'][0]
            q1_2 = questionnaire['Q1'][1]
            q1_3 = questionnaire['Q1'][2]
            q1_4 = questionnaire['Q1'][3]
            q1_5 = questionnaire['Q1'][4]
            q1_6 = questionnaire['Q1'][5]
            
            #Question 2
            q2_1 = True
            q2_2 = questionnaire['Q2'][0]
            q2_3 = questionnaire['Q2'][1]
            
            #Question 3
            q3_1 = True
            q3_2 = questionnaire['Q3'][0]
            
            #Question 4
            q4_1 = questionnaire['Q4'][0]
            
            #Question 5
            q5_1 = questionnaire['Q5'][0]
            
            #Question 6
            q6_1 = questionnaire['Q6'][0]
            q6_2 = questionnaire['Q6'][1]
            q6_3 = questionnaire['Q6'][2]
            q6_4 = questionnaire['Q6'][3]
            
            #Question 7 
            q7_1 = questionnaire['Q7'][0]
            q7_2 = questionnaire['Q7'][1]
            
            #Question 8
            q8_1 = questionnaire['Q8'][0]
            q8_2 = questionnaire['Q8'][1]
            
            #Question 9
            q9_1 = questionnaire['Q9'][0]
            
             
            #operate on rds with MySQL
            with conn.cursor() as cur:
                if timeslot == "morning":
                    cur.execute(f'SELECT * FROM Questionaire WHERE user_id = "{user_id}" AND stamp >= timestamp("{timestamp[0]} 07:00:00") AND stamp <= timestamp("{timestamp[0]} 11:00:00");') 
                elif timeslot == "lunch":
                    cur.execute(f'SELECT * FROM Questionaire WHERE user_id = "{user_id}" AND stamp >= timestamp("{timestamp[0]} 12:00:00") AND stamp <= timestamp("{timestamp[0]} 14:00:00");') 
                elif timeslot == "evening":
                    cur.execute(f'SELECT * FROM Questionaire WHERE user_id = "{user_id}" AND stamp >= timestamp("{timestamp[0]} 18:00:00") AND stamp <= timestamp("{timestamp[0]} 19:00:00");') 
                else:
                    continue
                
                result = cur.fetchone()
                
                if result is None:
                    cur.execute(f'INSERT INTO Questionaire (user_id, stamp, 1_1satisfaction, 1_2restlessnes, 1_3wellness, 1_4relaxeness, 1_5energy, 1_6tiredness, 2_2intenseNegativeEvent, 2_3intensePositiveEvent, 3_2likenessPeople, 4_1peopleAround, 5_1currentLocation, 6_1attentionOfCharacter, 6_2resurfaceingPast, 6_3thinkingAboutSelf, 6_4fightThougts, 7_1satisfaction, 7_2failure, 8_1impulsiveReacting, 8_2angerness, 9_1comments) VALUES ("{user_id}", "{wholestemp}", {q1_1}, {q1_2}, {q1_3}, {q1_4}, {q1_5}, {q1_6}, {q2_2}, {q2_3}, {q3_2}, "{q4_1}", "{q5_1}", {q6_1}, {q6_2}, {q6_3}, {q6_4}, {q7_1}, {q7_2}, {q8_1}, {q8_2}, "{q9_1}")')
                    conn.commit()
             
         
    body = list()
    with conn.cursor() as cur:
         cur.execute(f'SELECT JSON_OBJECT("Q1", JSON_ARRAY(1_1satisfaction, 1_2restlessnes, 1_3wellness, 1_4relaxeness, 1_5energy, 1_6tiredness), "Q2", JSON_ARRAY(2_3intensePositiveEvent, 2_2intenseNegativeEvent), "Q3", JSON_ARRAY(3_2likenessPeople), "Q4", JSON_ARRAY(4_1peopleAround), "Q5", JSON_ARRAY(5_1currentLocation), "Q6", JSON_ARRAY(6_1attentionOfCharacter, 6_2resurfaceingPast, 6_3thinkingAboutSelf, 6_4fightThougts), "Q7", JSON_ARRAY(7_1satisfaction, 7_2failure), "Q8", JSON_ARRAY(8_1impulsiveReacting, 8_2angerness), "Q9", JSON_ARRAY(9_1comments), "timestamp", stamp, "user_id", user_id) AS json_object FROM Questionaire WHERE user_id = "{user_id}" ORDER BY stamp;')
         result2 = cur.fetchall()
         print(result2)
         for x in result2:
             body.append(x[0])
    
    http_res['body'] = json.dumps(body)
    #return successful http res
    return http_res