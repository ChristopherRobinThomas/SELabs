import json
import boto3

def lambda_handler(event, context):
    
    data = event['body']
    message = json.loads(data)
    
    BUCKET = message['bucket']
    OBJECT = message['object']
    
    
    
    s3_client = boto3.client('s3',region_name="eu-north-1", config=boto3.session.Config(signature_version='s3v4'))
    
    try:
        url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket' : BUCKET, 'Key' : OBJECT},
            ExpiresIn=3600)
            
    except Exception as e:
        print(e)
        raise e
    
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    http_res['body'] = json.dumps(url)
    
    return http_res
