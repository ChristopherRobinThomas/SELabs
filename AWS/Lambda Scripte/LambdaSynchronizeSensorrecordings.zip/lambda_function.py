import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['Sensorrecordings']['values']
    
    print(message) 
    user_id = data2['nameValuePairs']['user_id'] 
    
    if (message != ['']):

        for sensorrecording in message:
            #retrieve all Data from Body in individual variables:
            #additional Data
            print(sensorrecording)
            
            sensorrecording = json.loads(rf'{sensorrecording}')
            wholestemp = sensorrecording['timestamp']
            timestamp = wholestemp.split(" ")
            daytime = timestamp[1].split(":")
            
            acceleration = sensorrecording['acceleration']
            stepcounter = sensorrecording['stepcounter']
            distance = sensorrecording['distance']
            height = sensorrecording['height']
            velocity = sensorrecording['velocity']
            
            #operate on rds with MySQL
            with conn.cursor() as cur:
                cur.execute(f'SELECT * FROM Sensorrecordings WHERE user_id = "{user_id}" AND stamp = timestamp("{wholestemp}");') 
        
                result = cur.fetchone()
                
                if result is None:
                    cur.execute(f'INSERT INTO Sensorrecordings (user_id, stamp, acceleration, stepcount, distance, height, velocity) VALUES ("{user_id}", "{wholestemp}", "{acceleration}", "{stepcounter}", "{distance}", "{height}", "{velocity}");')
                    conn.commit()
             
    body = list()
    with conn.cursor() as cur:
         cur.execute(f'SELECT JSON_OBJECT("timestamp", stamp, "acceleration", acceleration, "stepcounter", stepcount, "distance", distance, "height", height, "velocity", velocity, "user_id", user_id) AS json_object FROM Sensorrecordings WHERE user_id = "{user_id}" ORDER BY stamp;')
         result2 = cur.fetchall()
         print(result2)
         for x in result2:
             body.append(x[0])
    
    http_res['body'] = json.dumps(body)
    #return successful http res
    return http_res