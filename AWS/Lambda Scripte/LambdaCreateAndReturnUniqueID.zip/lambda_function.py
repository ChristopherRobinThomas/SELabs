import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    
    #Works, don´t touch it!!!
    #data1 = event['body']
    #data2 = json.loads(data1)
    #message = data2['nameValuePairs']

    #gives UUID() function 6 times to create a unique UUID (just failsafe)
    for x in range(6):
        try:
            with conn.cursor() as cur:
                cur.execute(f'SELECT UUID()') #create a UUID
                result = cur.fetchone()
                cur.execute(f'INSERT INTO UniqueUserId (user_id) VALUES ("{result[0]}")') #Add UUID to table
                conn.commit()
            http_res['body'] = json.dumps(result) #returns UUID
            break;
        except conn.Error as err:
            http_res['body'] = json.dumps("-1") #returns -1 if no UUID could be created
        

    
    #return successful http response
    return http_res