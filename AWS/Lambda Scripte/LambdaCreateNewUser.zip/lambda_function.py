import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
databasePassword = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=databasePassword, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']

    username = message['username']
    password = message['password']
    
    print("Message: " + str(message))

    

    for x in range(6): #gives UUID() function 6 times to create a unique UUID (just failsafe)
        try:
            with conn.cursor() as cur:
                #checks if kombi of username and password is already in use and returns the UUID
                cur.execute(f'SELECT user_id FROM UniqueUserId WHERE user_name = "{username}" AND user_password = "{password}";')
                result = cur.fetchone()
                if result != None:
                    http_res['body'] = json.dumps([result[0], "login"])
                    break;
                
                #checks if a Username is there but the password is wrong 
                cur.execute(f'SELECT user_id FROM UniqueUserId WHERE user_name = "{username}" AND user_password != "{password}";') 
                result = cur.fetchone()
                if result != None:
                    http_res['body'] = json.dumps(["-3", "failed"]) #return -3 if Username is in use but password is wrong
                    break;
                        
                #create a UUID
                cur.execute(f'SELECT UUID()') 
                result = cur.fetchone()
                cur.execute(f'INSERT INTO UniqueUserId (user_id, user_name, user_password) VALUES ("{result[0]}", "{username}", "{password}")') #Add UUID to table
                conn.commit()
                http_res['body'] = json.dumps([result[0], "create"]) #returns UUID
                break;
                
                
                
        except conn.Error as err:
            print("SQL Error: " + str(err))
            http_res['body'] = json.dumps(["-1", str(err)]) #returns -1 if no UUID could be created
    
    #return successful http response
    return http_res