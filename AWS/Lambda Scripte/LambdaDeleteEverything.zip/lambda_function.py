import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    print(event)
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']

    user_id = message['user_id']
        
    with conn.cursor() as cur:
        cur.execute(f'DELETE FROM DigitSpanTask WHERE user_id = "{user_id}";') 
        cur.execute(f'DELETE FROM Questionaire WHERE user_id = "{user_id}";')
        cur.execute(f'DELETE FROM UniqueUserId WHERE user_id = "{user_id}";')
        cur.execute(f'DELETE FROM completedInterventions WHERE user_id = "{user_id}";')
        cur.execute(f'DELETE FROM DailyGoal WHERE user_id = "{user_id}";')
        cur.execute(f'DELETE FROM interventions WHERE user_id = "{user_id}";')
        cur.execute(f'DELETE FROM Sensorrecordings WHERE user_id = "{user_id}";')
        conn.commit()
    http_res['body'] = 1
            
    
    #return successful http response
    return http_res