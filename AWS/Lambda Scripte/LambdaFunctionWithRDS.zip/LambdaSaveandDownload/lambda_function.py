import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['Questionnaires']['values']


    #retrieve all Data from Body in individual variables:
    #additional Data
    user_id = message['user_id']
    stemp = message['timestamp']
        
    #Question 1
    q1_1 = message['Q1']['values'][0]
    q1_2 = message['Q1']['values'][1]
    q1_3 = message['Q1']['values'][2]
    q1_4 = message['Q1']['values'][3]
    q1_5 = message['Q1']['values'][4]
    q1_6 = message['Q1']['values'][5]
        
    #Question 2
    q2_2 = message['Q2']['values'][0]
    q2_3 = message['Q2']['values'][1]
        
    #Question 3
    q3_2 = message['Q3']['values'][0]
        
    #Question 4
    q4_1 = message['Q4']['values'][0]
    
    #Question 5
    q5_1 = message['Q5']['values'][0]
        
    #Question 6
    q6_1 = message['Q6']['values'][0]
    q6_2 = message['Q6']['values'][1]
    q6_3 = message['Q6']['values'][2]
    q6_4 = message['Q6']['values'][3]
        
    #Question 7 
    q7_1 = message['Q7']['values'][0]
    q7_2 = message['Q7']['values'][1]
        
    #Question 8
    q8_1 = message['Q8']['values'][0]
    q8_2 = message['Q8']['values'][1]
        
    #Question 9
    q9_1 = message['Q9']['values'][0]
        
        
    #operate on rds with MySQL
    with conn.cursor() as cur:
        cur.execute(f'INSERT INTO Questionaire (user_id, stamp, 1_1satisfaction, 1_2restlessnes, 1_3wellness, 1_4relaxeness, 1_5energy, 1_6tiredness, 2_2intenseNegativeEvent, 2_3intensePositiveEvent, 3_2likenessPeople, 4_1peopleAround, 5_1currentLocation, 6_1attentionOfCharacter, 6_2resurfaceingPast, 6_3thinkingAboutSelf, 6_4fightThougts, 7_1satisfaction, 7_2failure, 8_1impulsiveReacting, 8_2angerness, 9_1comments) VALUES ("{user_id}", "{stemp}", {q1_1}, {q1_2}, {q1_3}, {q1_4}, {q1_5}, {q1_6}, {q2_2}, {q2_3}, {q3_2}, "{q4_1}", "{q5_1}", {q6_1}, {q6_2}, {q6_3}, {q6_4}, {q7_1}, {q7_2}, {q8_1}, {q8_2}, "{q9_1}")')
        conn.commit()
            
            
    #return successful http res
    http_res['body'] = json.dumps(event)
    return http_res