import sys
import logging
import pymysql
import json
import time
from datetime import datetime

# rds settings
rds_host  = "se-labs-database.cmqyp2lhhp5d.eu-north-1.rds.amazonaws.com"
user_name = "admin"
password = "adminadmin"
db_name = "SELabs2023"


#connecting to rds:
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    sys.exit()



def lambda_handler(event, context):
    
    #create response Header
    http_res = {}
    http_res['statusCode'] = 200
    http_res['headers'] = {}
    http_res['headers']['Content-Type'] = 'application/json'
    
    #Works, don´t touch it!!!
    data1 = event['body']
    data2 = json.loads(data1)
    message = data2['nameValuePairs']['interventions']
    user_id = data2['nameValuePairs']['user_id'] 
    print(user_id)
    
    if (message != ['']):
        #operate on rds with MySQL
        with conn.cursor() as cur:
            cur.execute(f'SELECT * FROM interventions WHERE user_id = "{user_id}";') 
    
            result = cur.fetchone()
            
            if result is None:
                cur.execute(f"INSERT INTO interventions (user_id, intervention) VALUES ('{user_id}', '{message}');")
                conn.commit()
            elif len(result[2]) < len(message):
                cur.execute(f'DELETE  FROM interventions WHERE user_id = "{user_id}";')
                cur.execute(f"INSERT INTO interventions (user_id, intervention) VALUES ('{user_id}', '{message}');")
                conn.commit()
                
                
    with conn.cursor() as cur:
         cur.execute(f'SELECT intervention FROM interventions WHERE user_id = "{user_id}"')
         result2 = cur.fetchone()

    
    http_res['body'] = json.dumps(result2[0])
    #return successful http res
    return http_res